<?php
define('WEBIMVAR_ENTERPRISE', true);
define('APP_ENVIRONMENT', 'development');
require dirname(__DIR__).'/core/config.php';
echo "ping ok";