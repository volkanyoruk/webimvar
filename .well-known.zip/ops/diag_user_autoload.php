<?php
// ops/diag_user_autoload.php
define('WEBIMVAR_ENTERPRISE', true);
require __DIR__ . '/../core/config.php';

$path = __DIR__ . '/models/User.php';
echo 'Looking for: ' . $path . PHP_EOL;
echo (is_file($path) ? "FOUND file\n" : "MISSING file\n");
echo 'Autoloader paths OK. Trying class_exists("User")...' . PHP_EOL;
echo (class_exists('User') ? "CLASS OK\n" : "CLASS NOT FOUND\n");
