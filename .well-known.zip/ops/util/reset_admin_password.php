<?php
// public_html/ops/util/reset_admin_password.php
// AMAÇ: Tek seferlik admin şifresi sıfırlama. İŞİN BİTİNCE BU DOSYAYI SİL!

declare(strict_types=1);

// config.php bunu bekliyor
define('WEBIMVAR_ENTERPRISE', true);

// config + autoload
require dirname(__DIR__) . '/../core/config.php';

/**
 * Güvenlik: basit token kontrolü.
 * ➜ Bu değeri yüklemeden önce değiştir!
 */
$EXPECTED_TOKEN = 'XWbV-ops-Reset-Only-Once';

/* ---- Parametreler ---- */
$token = $_GET['token'] ?? '';
$email = trim((string)($_GET['email'] ?? 'admin@webimvar.com'));
$new   = (string)($_GET['pass']  ?? '');

/* ---- Basit kontroller ---- */
if ($token !== $EXPECTED_TOKEN) {
    http_response_code(403);
    echo 'FORBIDDEN: invalid token.';
    exit;
}

if ($email === '' || $new === '') {
    http_response_code(400);
    echo 'ERROR: email ve pass parametreleri zorunlu. Örnek: ?token=TOKEN&email=admin@webimvar.com&pass=YeniGuclu!123';
    exit;
}

/* ---- İşlem ---- */
try {
    $db = Database::getInstance();

    // Kullanıcı var mı?
    $row = $db->queryOne(
        "SELECT id FROM users WHERE email = :email LIMIT 1",
        ['email' => mb_strtolower($email)]
    );
    if (!$row || empty($row['id'])) {
        echo "ERROR: user not found ($email)";
        exit;
    }

    // Parolayı güncelle
    $hash = password_hash($new, PASSWORD_DEFAULT);
    $db->update(
        'users',
        ['password' => $hash, 'updated_at' => date('Y-m-d H:i:s')],
        'id = :id',
        ['id' => (int)$row['id']]
    );

    echo "OK: password updated for $email. Şimdi yeni şifre ile giriş yapabilirsiniz.";
} catch (Throwable $e) {
    echo 'ERROR: ' . $e->getMessage();
}