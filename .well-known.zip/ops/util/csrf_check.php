<?php
// Güvenlik kilidi – config.php bu sabiti bekliyor
define('WEBIMVAR_ENTERPRISE', true);

// Bootstrap
require __DIR__ . '/../../core/config.php';
require_once __DIR__ . '/../../core/classes/Session.php';

Session::start();

// Oturum CSRF yoksa test için üret (login sayfasıyla da aynı anahtarı kullanır)
$csrf = Session::get('csrf');
if (!$csrf) {
    $csrf = bin2hex(random_bytes(16));
    Session::set('csrf', $csrf);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: text/plain; charset=utf-8');
    $postCsrf = $_POST['csrf'] ?? '';
    echo "SESSION ID : " . session_id() . PHP_EOL;
    echo "SESSION CSRF: " . ($csrf ?? '(yok)') . PHP_EOL;
    echo "POST CSRF   : " . ($postCsrf ?: '(yok)') . PHP_EOL;
    echo "MATCH?      : " . (($postCsrf === ($csrf ?? null)) ? 'YES' : 'NO') . PHP_EOL;
    echo "POST email  : " . ($_POST['email'] ?? '(yok)') . PHP_EOL;
    echo "POST pass   : " . ((isset($_POST['password']) && $_POST['password'] !== '') ? '(filled)' : '(empty)') . PHP_EOL;
    exit;
}
?>
<!doctype html>
<html lang="tr"><meta charset="utf-8">
<title>CSRF Check</title>
<body style="font-family:ui-sans-serif,system-ui;margin:24px">
<h2>CSRF Check</h2>
<p><b>SESSION ID:</b> <?=htmlspecialchars(session_id(),ENT_QUOTES,'UTF-8')?></p>
<p><b>SESSION CSRF:</b> <?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?></p>

<hr>
<h3>1) Bu sayfaya POST gönder (debug)</h3>
<form method="post">
  <div><input type="email" name="email" placeholder="E-posta"></div>
  <div><input type="password" name="password" placeholder="Şifre"></div>
  <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?>">
  <button type="submit">Bu sayfaya POST</button>
</form>

<hr>
<h3>2) Gerçek endpoint’e POST gönder (/ops/login)</h3>
<form method="post" action="/ops/login">
  <div><input type="email" name="email" placeholder="E-posta"></div>
  <div><input type="password" name="password" placeholder="Şifre"></div>
  <input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?>">
  <button type="submit">/ops/login’a POST</button>
</form>
</body></html>