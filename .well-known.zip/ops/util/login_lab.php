<?php
declare(strict_types=1);
define('WEBIMVAR_ENTERPRISE', true);

require __DIR__ . '/../../core/config.php';
require __DIR__ . '/../../core/classes/Session.php';

Session::start();

// CSRF üret
if (!Session::get('csrf')) {
    Session::set('csrf', bin2hex(random_bytes(16)));
}
$csrf   = (string) Session::get('csrf');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// POST geldiyse debug bilgisi hazırlayalım
$debug = [];
if ($method === 'POST') {
    $postCsrf = (string)($_POST['csrf'] ?? '');
    $csrfOk   = ($csrf && $postCsrf && hash_equals($csrf, $postCsrf));
    $debug = [
        'SESSION ID'   => session_id(),
        'SESSION CSRF' => $csrf ?: '(none)',
        'POST CSRF'    => $postCsrf ?: '(empty)',
        'CSRF OK?'     => $csrfOk ? 'YES' : 'NO',
        'POST email'   => (string)($_POST['email'] ?? '(empty)'),
        'POST pass'    => isset($_POST['password']) && $_POST['password'] !== '' ? '(filled)' : '(empty)',
    ];
}
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Login LAB</title>
  <style>
    body { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; background:#0b0f19; color:#e5e7eb; padding:16px; }
    h1 { font-size:20px; margin:0 0 12px; }
    .card { background:#111827; border:1px solid #1f2937; padding:16px; border-radius:8px; margin-bottom:16px; }
    .row { margin-bottom:8px; }
    input { padding:8px; border-radius:6px; border:1px solid #374151; background:#0b1220; color:#e5e7eb; width:280px; }
    button { padding:8px 14px; border-radius:6px; border:0; background:#111827; color:#e5e7eb; cursor:pointer; }
    button:hover { background:#1f2937; }
    pre { white-space:pre-wrap; }
  </style>
</head>
<body>

<h1>== LOGIN LAB ==</h1>

<div class="card">
  <div class="row"><strong>Oturum</strong></div>
  <pre>SESSION ID  : <?= htmlspecialchars(session_id(), ENT_QUOTES, 'UTF-8') . "\n" ?>
SESSION CSRF: <?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?></pre>
</div>

<?php if ($method === 'POST'): ?>
<div class="card">
  <div class="row"><strong>POST Debug</strong></div>
  <pre><?php
      foreach ($debug as $k => $v) {
          echo htmlspecialchars($k . ' : ' . $v, ENT_QUOTES, 'UTF-8') . "\n";
      }
  ?></pre>
</div>
<?php endif; ?>

<div class="card">
  <div class="row"><strong>Gerçek Login testi → /ops/login</strong></div>
  <form method="post" action="/ops/login">
    <div class="row"><input type="email" name="email" placeholder="E-posta" required></div>
    <div class="row"><input type="password" name="password" placeholder="Şifre" required></div>
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
    <button type="submit">/ops/login POST Gönder</button>
  </form>
</div>

<div class="card">
  <div class="row"><strong>POST bana geldi mi? → /ops/util/login_lab.php</strong></div>
  <form method="post" action="/ops/util/login_lab.php">
    <div class="row"><input type="email" name="email" placeholder="E-posta" required></div>
    <div class="row"><input type="password" name="password" placeholder="Şifre" required></div>
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
    <button type="submit">Bu sayfaya POST Gönder</button>
  </form>
</div>

</body>
</html>