<?php
session_start();
$csrf = bin2hex(random_bytes(16));
$_SESSION['csrf'] = $csrf; // sadece örnek, zorunlu değil
?>
<!doctype html>
<meta charset="utf-8">
<title>POST Probe</title>
<h3>POST Probe → /ops/util/echo_post.php</h3>
<form method="post" action="/ops/util/echo_post.php">
  <div><input name="email" placeholder="email"></div>
  <div><input name="password" type="password" placeholder="password"></div>
  <div><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?>"></div>
  <button type="submit">POST Gönder</button>
</form>