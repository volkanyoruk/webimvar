<?php
declare(strict_types=1);
define('WEBIMVAR_ENTERPRISE', true);
require __DIR__ . '/../../core/config.php';
require __DIR__ . '/../../core/classes/Session.php';
require __DIR__ . '/../../core/classes/Database.php';

Session::start();

header('Content-Type: text/plain; charset=UTF-8');

echo "== LOGIN DEBUG ==\n\n";
echo "METHOD: " . $_SERVER['REQUEST_METHOD'] . "\n";
echo "SESSION ID: " . session_id() . "\n";

$session_csrf = Session::get('csrf') ?? '';
$post_csrf    = $_POST['csrf'] ?? '';

echo "SESSION CSRF: $session_csrf\n";
echo "POST CSRF   : $post_csrf\n";
echo "CSRF OK?    : " . ((is_string($session_csrf) && $post_csrf && hash_equals($session_csrf, $post_csrf)) ? 'YES' : 'NO') . "\n\n";

$email = $_POST['email'] ?? '';
$pass  = $_POST['password'] ?? '';

echo "POST email  : $email\n";
echo "POST pass   : " . (strlen($pass) ? ('*** (len=' . strlen($pass) . ')') : '(empty)') . "\n\n";

try {
    $db  = Database::getInstance();
    $row = $db->queryOne("SELECT id,email,full_name,is_active,password FROM users WHERE email=:e LIMIT 1", ['e'=>$email]);

    if (!$row) {
        echo "DB: USER NOT FOUND\n";
        exit;
    }
    echo "DB: USER FOUND id={$row['id']} is_active={$row['is_active']}\n";

    $ok = password_verify($pass, $row['password']);
    echo "password_verify: " . ($ok ? "OK\n" : "FAIL\n");

} catch (Throwable $e) {
    echo "DB ERROR: " . $e->getMessage() . "\n";
}