<?php
declare(strict_types=1);
define('WEBIMVAR_ENTERPRISE', true);
require __DIR__ . '/../../core/config.php';

// Son PHP hatalarını göster (üretimde KULLANMA, işin bitince dosyayı sil)
$log = LOGS_PATH . 'php_errors.log';
header('Content-Type: text/plain; charset=UTF-8');
if (is_readable($log)) {
    readfile($log);
} else {
    echo "Log bulunamadı: $log\n";
}