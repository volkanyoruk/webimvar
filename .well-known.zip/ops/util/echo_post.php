<?php
header('Content-Type: text/plain; charset=UTF-8');
session_start();
echo "METHOD: " . ($_SERVER['REQUEST_METHOD'] ?? '') . PHP_EOL;
echo "POST:\n";
var_export($_POST);
echo PHP_EOL;