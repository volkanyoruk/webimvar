<?php
declare(strict_types=1);
define('WEBIMVAR_ENTERPRISE', true);
require_once __DIR__ . '/../../core/config.php';
require_once __DIR__ . '/../../core/classes/Database.php';

header('Content-Type: text/plain; charset=utf-8');

$db = Database::getInstance();

echo "users(is_active=1): ";
print_r($db->queryOne("SELECT COUNT(*) c FROM users WHERE is_active=1"));

echo PHP_EOL . "sites(active): ";
try {
  print_r($db->queryOne("SELECT COUNT(*) c FROM sites WHERE status='active'"));
} catch (Throwable $e) { echo "TABLO YOK veya 0\n"; }

echo PHP_EOL . "failed logins 24h: ";
try {
  print_r($db->queryOne("
    SELECT COUNT(*) c FROM system_logs
    WHERE action='login_failed' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)
  "));
} catch (Throwable $e) { echo "TABLO YOK veya 0\n"; }

echo PHP_EOL . "avg query ms 24h: ";
try {
  print_r($db->queryOne("
    SELECT ROUND(AVG(metric_value),2) ms FROM system_stats
    WHERE metric_name='query_time_ms' AND recorded_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)
  "));
} catch (Throwable $e) { echo "TABLO YOK veya NULL\n"; }

echo PHP_EOL . "DONE\n";