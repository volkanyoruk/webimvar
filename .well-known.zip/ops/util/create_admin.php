<?php
// public_html/ops/util/create_admin.php
ini_set('display_errors','1'); error_reporting(E_ALL);

// Config guard (config.php bu sabitlerden birini bekliyor)
define('WEBIMVAR_ENTERPRISE', true);

require dirname(__DIR__) . '/../core/config.php';

try {
    // Database sınıfı autoloader ile yüklenecek (gerekirse ayrıca include edilebilir)
    $db = Database::getInstance();

    $email = 'admin@webimvar.com';
    $username = 'admin';
    $fullName = 'Süper Yönetici';
    $role = 'super_admin';
    $plain = 'Admin!123';

    // Mevcut mu?
    $row = $db->queryOne("SELECT id FROM users WHERE email = :email LIMIT 1", ['email' => $email]);
    if ($row && isset($row['id'])) {
        echo "ALREADY EXISTS - admin zaten var (id: {$row['id']}) | email: $email";
        exit;
    }

    $hash = password_hash($plain, PASSWORD_DEFAULT);

    $id = $db->insert('users', [
        'username'      => $username,
        'email'         => $email,
        'password'      => $hash,
        'full_name'     => $fullName,
        'role'          => $role,
        'is_active'     => 1,
        'login_count'   => 0,
        'failed_attempts' => 0,
        'created_at'    => date('Y-m-d H:i:s'),
        'updated_at'    => date('Y-m-d H:i:s')
    ]);

    echo "OK - admin oluşturuldu (id: $id) | email: $email | şifre: $plain";
} catch (Throwable $e) {
    echo "HATA: " . $e->getMessage();
}
