<?php
// Webimvar Ops - Front Controller (tam dosya)
declare(strict_types=1);

define('WEBIMVAR_ENTERPRISE', true);

$OPS = __DIR__;
require $OPS . '/../core/config.php';
require $OPS . '/../core/classes/Session.php';
require $OPS . '/../core/classes/Database.php';

Session::start();

// --- yardımcılar ---
function path_now(): string {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $qpos = strpos($uri, '?');
    if ($qpos !== false) $uri = substr($uri, 0, $qpos);
    // //ops/ -> /ops/ normalizasyonu
    $uri = rtrim($uri, '/') ?: '/';
    return $uri === '/ops' ? '/ops/' : $uri;
}
function redirect(string $to): void {
    header('Location: ' . $to, true, 302);
    exit;
}
function csrf_get(): string {
    $t = Session::get('csrf', '');
    if (!$t) {
        $t = bin2hex(random_bytes(16));
        Session::set('csrf', $t);
    }
    return $t;
}
function csrf_ok_from_post(): bool {
    $sess = (string) Session::get('csrf', '');
    $post = (string) ($_POST['csrf'] ?? '');
    return ($sess !== '' && $post !== '' && hash_equals($sess, $post));
}
function pdo(): PDO {
    // Database wrapper yoksa direkt PDO aç
    if (class_exists('Database')) {
        if (method_exists('Database', 'get')) {
            $db = Database::get();
            if ($db instanceof PDO) return $db;
        } elseif (method_exists('Database', 'pdo')) {
            $db = Database::pdo();
            if ($db instanceof PDO) return $db;
        }
    }
    return new PDO(
        'mysql:host=' . DatabaseConfig::HOST . ';dbname=' . DatabaseConfig::DATABASE . ';charset=' . DatabaseConfig::CHARSET,
        DatabaseConfig::USERNAME,
        DatabaseConfig::PASSWORD,
        DatabaseConfig::OPTIONS
    );
}

// --- router ---
$path   = path_now();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// /ops/ => login ya da dashboard
if ($path === '/ops/') {
    if (Session::get('user_id')) redirect('/ops/dashboard');
    redirect('/ops/login');
}

// GET /ops/login : form göster
if ($path === '/ops/login' && $method === 'GET') {
    $title = 'Giriş';
    $csrf  = csrf_get();
    // flash (basit)
    $err   = Session::get('flash_err', null);
    if ($err !== null) Session::remove('flash_err');
    include __DIR__ . '/templates/auth/login.php';
    exit;
}

// POST /ops/login : doğrula
if ($path === '/ops/login' && $method === 'POST') {
    if (!csrf_ok_from_post()) {
        Session::set('flash_err', 'Geçersiz istek veya CSRF eşleşmedi.');
        redirect('/ops/login');
    }

    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL) ?: '';
    $pass  = (string) ($_POST['password'] ?? '');

    if ($email === '' || $pass === '') {
        Session::set('flash_err', 'E-posta ve şifre zorunlu.');
        redirect('/ops/login');
    }

    try {
        $db = pdo();
        $st = $db->prepare('SELECT id,email,name,password_hash,is_active FROM users WHERE email=? LIMIT 1');
        $st->execute([$email]);
        $u = $st->fetch(PDO::FETCH_ASSOC);

        if ($u && (int)$u['is_active'] === 1 && password_verify($pass, $u['password_hash'])) {
            Session::regenerate();
            Session::set('user_id', (int)$u['id']);
            Session::set('user_email', $u['email']);
            Session::set('user_name', $u['name'] ?? 'Admin');
            redirect('/ops/dashboard');
        }
    } catch (Throwable $e) {
        error_log('[ops-login] ' . $e->getMessage());
    }

    Session::set('flash_err', 'Geçersiz e-posta veya şifre.');
    redirect('/ops/login');
}

// GET /ops/dashboard : basit dashboard ya da template
if ($path === '/ops/dashboard') {
    if (!Session::get('user_id')) redirect('/ops/login');

    // Template varsa onu yükle; yoksa basit çıktı
    $tpl = __DIR__ . '/templates/admin/dashboard.php';
    if (is_file($tpl)) {
        $title = 'Dashboard';
        include $tpl;
    } else {
        header('Content-Type: text/html; charset=UTF-8');
        echo '<h1>Webimvar Ops</h1>';
        echo '<p>Giriş başarılı.</p>';
        echo '<p><a href="/ops/logout">Çıkış</a></p>';
    }
    exit;
}

// GET /ops/logout
if ($path === '/ops/logout') {
    Session::destroy();
    redirect('/ops/login');
}

// 404
http_response_code(404);
header('Content-Type: text/plain; charset=UTF-8');
echo 'Not Found: ' . $path;