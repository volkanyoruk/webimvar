<?php
ini_set('display_errors','1'); error_reporting(E_ALL);
echo 'PDO class: ' . (class_exists('PDO') ? 'YES' : 'NO') . "<br>";
if (class_exists('PDO')) {
    $drivers = PDO::getAvailableDrivers();
    echo 'PDO drivers: ' . implode(', ', $drivers);
}