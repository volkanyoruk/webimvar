<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <title><?= isset($title) ? $title.' — ' : '' ?>Webimvar Ops</title>
</head>
<body class="min-h-screen bg-slate-50 text-slate-900">
  <header class="bg-white border-b">
    <div class="mx-auto max-w-6xl px-4 py-3 flex justify-between items-center">
      <div class="font-semibold">Webimvar Ops</div>
      <form method="post" action="/ops/logout">
        <button class="text-sm px-3 py-1 rounded bg-slate-900 text-white">Çıkış</button>
      </form>
    </div>
  </header>
  <main class="mx-auto max-w-6xl px-4 py-8">
    <?= $content ?? '' ?>
  </main>
</body>
</html>