<?php
define('WEBIMVAR_ENTERPRISE', true);
require __DIR__ . '/../core/config.php';
require __DIR__ . '/../core/classes/Session.php';
Session::start();
if (!Session::has('user_id')) { header('Location: /ops/login'); exit; }

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DatabaseConfig::HOST . ';dbname=' . DatabaseConfig::DATABASE . ';charset=' . DatabaseConfig::CHARSET;
        $pdo = new PDO($dsn, DatabaseConfig::USERNAME, DatabaseConfig::PASSWORD, DatabaseConfig::OPTIONS);
    }
    return $pdo;
}

$users    = db()->query("SELECT COUNT(*) FROM users WHERE is_active=1")->fetchColumn();
$sites    = db()->query("SELECT COUNT(*) FROM sites  WHERE is_active=1")->fetchColumn();
$fails24h = db()->query("SELECT COUNT(*) FROM login_attempts WHERE success=0 AND created_at>=NOW()-INTERVAL 1 DAY")->fetchColumn();
?><!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard — Webimvar Ops</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-100 text-slate-900">
<header class="bg-white border-b">
  <div class="max-w-5xl mx-auto px-4 py-3 flex justify-between items-center">
    <div class="font-semibold">Webimvar Ops</div>
    <form action="/ops/logout" method="post">
      <button class="text-sm px-3 py-1 rounded bg-slate-900 text-white">Çıkış</button>
    </form>
  </div>
</header>
<main class="max-w-5xl mx-auto px-4">
  <div class="grid gap-4 grid-cols-1 md:grid-cols-4 mt-6">
    <div class="bg-white p-4 rounded-xl shadow">
      <div class="text-sm text-slate-500">Aktif Kullanıcı</div>
      <div class="text-2xl font-semibold"><?= (int)$users ?></div>
    </div>
    <div class="bg-white p-4 rounded-xl shadow">
      <div class="text-sm text-slate-500">Aktif Site</div>
      <div class="text-2xl font-semibold"><?= (int)$sites ?></div>
    </div>
    <div class="bg-white p-4 rounded-xl shadow">
      <div class="text-sm text-slate-500">24s Başarısız Giriş</div>
      <div class="text-2xl font-semibold"><?= (int)$fails24h ?></div>
    </div>
    <div class="bg-white p-4 rounded-xl shadow">
      <div class="text-sm text-slate-500">Ortalama Sorgu Süresi</div>
      <div class="text-2xl font-semibold">—</div>
    </div>
  </div>
</main>
</body>
</html>