<?php
ini_set('display_errors','1'); error_reporting(E_ALL);

$checks = [
  __DIR__ . '/../core/config.php',
  __DIR__ . '/../core/classes/Response.php',
  __DIR__ . '/../core/classes/Router.php',
  __DIR__ . '/../core/classes/Session.php',
  __DIR__ . '/../core/classes/Database.php',
  __DIR__ . '/templates/auth/login.php',
  __DIR__ . '/templates/layouts/admin.php',
];

foreach ($checks as $f) {
  echo (is_file($f) ? 'OK  ' : 'NO! ') . $f . "<br>";
}